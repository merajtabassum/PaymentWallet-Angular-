import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user/userservice';
import { Transaction } from '../transaction';

@Component({
  selector: 'app-showsenttransactions',
  templateUrl: './showsenttransactions.component.html',
  styleUrls: ['./showsenttransactions.component.css']
})
export class ShowsenttransactionsComponent implements OnInit {
 transaction:Transaction[];
  constructor(private userService:UserService) { }

  get mobileno():number{
    return this.userService.sharedno;
  }
  showSentTransactions():void
  {
    this.userService.sentTransactions(this.mobileno).subscribe(data=>this.transaction=data);
  }
  ngOnInit(): void {
  }

}
