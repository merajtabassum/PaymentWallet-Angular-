import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowsenttransactionsComponent } from './showsenttransactions.component';

describe('ShowsenttransactionsComponent', () => {
  let component: ShowsenttransactionsComponent;
  let fixture: ComponentFixture<ShowsenttransactionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowsenttransactionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowsenttransactionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
