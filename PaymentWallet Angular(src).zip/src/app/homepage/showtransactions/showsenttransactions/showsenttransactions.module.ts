import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShowsenttransactionsComponent } from './showsenttransactions.component';
import { Transaction } from '../transaction';



@NgModule({
  declarations: [ShowsenttransactionsComponent],
  imports: [
    CommonModule
  ],
  exports: [Transaction ]
})
export class ShowsenttransactionsModule { }
