import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShowtransactionsbetweendatesComponent } from './showtransactionsbetweendates.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [ShowtransactionsbetweendatesComponent],
  imports: [
    CommonModule,FormsModule
  ]
})
export class ShowtransactionsbetweendatesModule { }
