import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowtransactionsbetweendatesComponent } from './showtransactionsbetweendates.component';

describe('ShowtransactionsbetweendatesComponent', () => {
  let component: ShowtransactionsbetweendatesComponent;
  let fixture: ComponentFixture<ShowtransactionsbetweendatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowtransactionsbetweendatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowtransactionsbetweendatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
