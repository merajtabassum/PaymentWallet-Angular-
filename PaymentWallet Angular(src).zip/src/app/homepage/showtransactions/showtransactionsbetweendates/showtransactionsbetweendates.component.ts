import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user/userservice';
import { Transaction } from '../transaction';

@Component({
  selector: 'app-showtransactionsbetweendates',
  templateUrl: './showtransactionsbetweendates.component.html',
  styleUrls: ['./showtransactionsbetweendates.component.css']
})
export class ShowtransactionsbetweendatesComponent implements OnInit {
  trans:Transaction[];
  constructor(private userService:UserService) { }
  get mobileno():number{
    return this.userService.sharedno;
  } 
    fromdate:string;
    todate:string;
    showTransactionByDates():void
    {
      console.log(this.fromdate,this.todate)
      this.userService.transactionsByDates(this.fromdate,this.todate,this.mobileno).subscribe(data=>this.trans=data);
    }

  ngOnInit(): void {
  }

}
