import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowrecievedtransactionsComponent } from './showrecievedtransactions.component';

describe('ShowrecievedtransactionsComponent', () => {
  let component: ShowrecievedtransactionsComponent;
  let fixture: ComponentFixture<ShowrecievedtransactionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowrecievedtransactionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowrecievedtransactionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
