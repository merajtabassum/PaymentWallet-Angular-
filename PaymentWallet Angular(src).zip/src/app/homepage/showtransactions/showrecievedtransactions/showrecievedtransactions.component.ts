import { Component, OnInit } from '@angular/core';
import { Transaction } from '../transaction';
import { UserService } from 'src/app/user/userservice';

@Component({
  selector: 'app-showrecievedtransactions',
  templateUrl: './showrecievedtransactions.component.html',
  styleUrls: ['./showrecievedtransactions.component.css']
})
export class ShowrecievedtransactionsComponent implements OnInit {

  recievetrans:Transaction[];
  constructor(private userService:UserService) { }

  get mobileno():number{
    return this.userService.sharedno;
  }
  showRecievedTransactions():void
  {
    this.userService.recievedTransactions(this.mobileno).subscribe(data=>this.recievetrans=data);
  }
  ngOnInit(): void {
  }

}
