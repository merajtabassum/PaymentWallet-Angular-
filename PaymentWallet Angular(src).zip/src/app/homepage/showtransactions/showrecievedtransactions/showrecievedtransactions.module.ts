import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShowrecievedtransactionsComponent } from './showrecievedtransactions.component';
import { Transaction } from '../transaction';



@NgModule({
  declarations: [ShowrecievedtransactionsComponent],
  imports: [
    CommonModule
  ],
  exports: [Transaction ]
})
export class ShowrecievedtransactionsModule { }
