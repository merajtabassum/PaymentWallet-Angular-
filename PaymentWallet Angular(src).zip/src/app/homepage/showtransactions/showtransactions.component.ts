import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showtransactions',
  templateUrl: './showtransactions.component.html',
  styleUrls: ['./showtransactions.component.css']
})
export class ShowtransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
