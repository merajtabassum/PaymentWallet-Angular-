import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShowtransactionsComponent } from './showtransactions.component';
import { ShowtransactionsbetweendatesComponent } from './showtransactionsbetweendates/showtransactionsbetweendates.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from '../../app-routing.module';
import { ShowrecievedtransactionsComponent } from './showrecievedtransactions/showrecievedtransactions.component';
import { ShowsenttransactionsComponent } from './showsenttransactions/showsenttransactions.component';



@NgModule({
  declarations: [ShowtransactionsComponent, ShowtransactionsbetweendatesComponent,ShowsenttransactionsComponent,ShowrecievedtransactionsComponent],
  imports: [HttpClientModule,FormsModule ,RouterModule,AppRoutingModule,
    CommonModule
    ],
    bootstrap:[ShowsenttransactionsComponent],
    exports:[ShowtransactionsbetweendatesComponent,ShowrecievedtransactionsComponent,ShowsenttransactionsComponent]
})
export class ShowtransactionsModule { }
