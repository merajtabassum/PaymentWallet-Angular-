export class Transaction
{
    transactionId:number;
    sender:string;
    reciever:string;
    amount:number;
    smobileno:string;
    rmobileno:string;
    dateoftrans:string;
    status:string;
    public constructor(transactionId:number,sender:string,reciever:string,amount:number,smobileno:string,rmobileno:string,dateoftrans:string,status:string)
    {
        this. transactionId= transactionId;
        this.sender=sender;
        this.reciever=reciever;
        this.amount=amount;
        this.smobileno=smobileno;
        this.rmobileno=rmobileno;
        this.dateoftrans=dateoftrans;
        this.status=status;
    }
}
 