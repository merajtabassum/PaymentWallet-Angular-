import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferamounttoanotherwalletComponent } from './transferamounttoanotherwallet.component';

describe('TransferamounttoanotherwalletComponent', () => {
  let component: TransferamounttoanotherwalletComponent;
  let fixture: ComponentFixture<TransferamounttoanotherwalletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransferamounttoanotherwalletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferamounttoanotherwalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
