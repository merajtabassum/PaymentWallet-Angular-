import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user/userservice';

@Component({
  selector: 'app-transferamounttoanotherwallet',
  templateUrl: './transferamounttoanotherwallet.component.html',
  styleUrls: ['./transferamounttoanotherwallet.component.css']
})
export class TransferamounttoanotherwalletComponent implements OnInit {

  constructor(private userService:UserService) { }
  get mobileno():number{
    return this.userService.sharedno;
  } 
  toupi:number;
  uamount:number;
  pin:number;
tomobileno:number;
amount:number;
  sendAmount(){
    if (!this.tomobileno) {
      alert("Mobile Number cannot be null")
    }
    else if (this.mobileno==this.tomobileno ) {
      alert("Invalid Request")
    }
     else if ((!this.amount)||(this.amount==0) ) {
      alert("Amount cannot be Zero")
    }
    else{
      this.userService.transferAmount(this.mobileno,this.tomobileno, this.amount).subscribe((res: any) => {
        console.log("Amount Transferred");
      },
        (error) => {
          alert("bad Request");
          
        }
      );
      }
  }

  ngOnInit(): void {
  }
  sendAmountByUpi(){
    if (!this.toupi) {
      alert("Mobile Number cannot be null")
    }
    else if (this.mobileno==this.toupi ) {
      alert("Invalid Request")
    }
     else if ((!this.uamount)||(this.uamount==0) ) {
      alert("Amount cannot be Zero")
    }
    else{
      this.userService.transferAmountByUpi(this.mobileno,this.toupi, this.uamount,this.pin).subscribe((res: any) => {
        console.log("Amount Transferred");
      },
        (error) => {
          alert("bad Request");
          
        }
      );
      }
  }


}
