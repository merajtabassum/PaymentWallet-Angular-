import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransferamounttoanotherwalletComponent } from './transferamounttoanotherwallet.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [TransferamounttoanotherwalletComponent],
  imports: [
    CommonModule,FormsModule
  ]
})
export class TransferamounttoanotherwalletModule { }
