import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowwalletbalanceComponent } from './showwalletbalance.component';

describe('ShowwalletbalanceComponent', () => {
  let component: ShowwalletbalanceComponent;
  let fixture: ComponentFixture<ShowwalletbalanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowwalletbalanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowwalletbalanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
