import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user/userservice';

@Component({
  selector: 'app-showwalletbalance',
  templateUrl: './showwalletbalance.component.html',
  styleUrls: ['./showwalletbalance.component.css']
})
export class ShowwalletbalanceComponent implements OnInit {

  
  constructor(private userService:UserService) { }
  get mobileno():number{
    return this.userService.sharedno;
  }
  amount:any;
 accamount:any
  showWalletBalance():void{
    console.log(this.mobileno)
    this.userService.showBalance(this.mobileno).subscribe(data => this.amount=data)
  }
  showAccountBalance():void{
    console.log(this.mobileno)
    this.userService.showAccBalance(this.mobileno).subscribe(data => this.accamount=data)
  }
  ngOnInit(): void {
  }

}
