import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShowwalletbalanceComponent } from './showwalletbalance.component';



@NgModule({
  declarations: [ShowwalletbalanceComponent],
  imports: [
    CommonModule
  ]
})
export class ShowwalletbalanceModule { }
