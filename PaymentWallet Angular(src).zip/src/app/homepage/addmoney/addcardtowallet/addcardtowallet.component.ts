import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user/userservice';

@Component({
  selector: 'app-addcardtowallet',
  templateUrl: './addcardtowallet.component.html',
  styleUrls: ['./addcardtowallet.component.css']
})
export class AddcardtowalletComponent implements OnInit {
card:any={}
  public constructor(private userService:UserService){}

  ngOnInit(): void {
  }
  get mobileno():number{
    return this.userService.sharedno;
  } 
  addCard() {
    if (!this.card.cardholdername) {
      alert("Name cannot be null")
    } else if (!this.card.cardno) {
      alert("Card Number Cannot Be Null")
    }else if (!this.card.cardtype) {
        alert("Please Select a Card Type")   
    }else if ((!this.card.upiid)||(this.card.upiid!=this.mobileno)) {
        alert("Invalid UPI ID Your UPI ID is Your Mobileno")
    } else if (!this.card.cvv) {
          alert("email cannot be null")          
    } else {
      let options = {
        params: this.card
      }
      this.userService.addCard(options.params,this.mobileno).subscribe ((res: any)  => {
        alert("Card Added ")
      },
        (error) => {
          alert("Card not Added ")
          
        }
      );
  
}
  }

}
