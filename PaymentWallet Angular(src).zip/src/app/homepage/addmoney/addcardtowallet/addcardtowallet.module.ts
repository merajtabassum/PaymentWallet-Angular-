import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddcardtowalletComponent } from './addcardtowallet.component';



@NgModule({
  declarations: [AddcardtowalletComponent],
  imports: [
    CommonModule
  ]
})
export class AddcardtowalletModule { }
