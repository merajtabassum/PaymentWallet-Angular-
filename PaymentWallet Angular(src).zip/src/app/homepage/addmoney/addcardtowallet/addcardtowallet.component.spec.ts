import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddcardtowalletComponent } from './addcardtowallet.component';

describe('AddcardtowalletComponent', () => {
  let component: AddcardtowalletComponent;
  let fixture: ComponentFixture<AddcardtowalletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddcardtowalletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddcardtowalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
