import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetupiComponent } from './setupi.component';

describe('SetupiComponent', () => {
  let component: SetupiComponent;
  let fixture: ComponentFixture<SetupiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetupiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetupiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
