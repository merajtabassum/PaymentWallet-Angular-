import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user/userservice';

@Component({
  selector: 'app-setupi',
  templateUrl: './setupi.component.html',
  styleUrls: ['./setupi.component.css']
})
export class SetupiComponent implements OnInit {

  mobileno:any;
  pin:any;
  confirmpin:any;
  constructor(private userService:UserService) { }

  ngOnInit(): void {
  }
  setUpi() {
    if (!this.mobileno) {
      alert("Name cannot be null")
    } else if (this.pin!=this.confirmpin) {
      alert("Your Pin Doesn't Match your Confirm Pin")
    }
    else{
      this.userService.setUpi(this.mobileno,this.pin).subscribe((res: any) => {
        console.log("UPI  PIN has been Set Sucessfully");
      },
        (error) => {
          alert("bad Request");

}
      );
}
  }
}
