import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user/userservice';

@Component({
  selector: 'app-addmoneytowallet',
  templateUrl: './addmoneytowallet.component.html',
  styleUrls: ['./addmoneytowallet.component.css']
})
export class AddmoneytowalletComponent implements OnInit {

  get mobileno():number{
    return this.userService.sharedno;
  } 
  cvv:any;
  cardno:any;
  amount:any;
  uamount:any;
  upiid:any;
  pin:any;
  upi:any="@upi";
 public constructor(private userService:UserService) { }

  ngOnInit(): void {
  }
  showCards():void{
    this.userService.showCard(this.mobileno).subscribe(data=> this.cardno=data)

  }
  showUpi():void{
    this.userService.showUpi(this.mobileno).subscribe((res:any)=>
    {
      this.upiid=res+this.upi
    });

  }
  addMoney():void{
    if (!this.amount) {
      alert("enter valid amount")
    }
    else{
    this.userService.addMoneyToWallet(this.mobileno,this.cardno,this.amount,this.cvv).subscribe((res: any) => {
     console.log("Added money");
      alert("Money Added")
    },
      (err) => {
        alert("Insufficient Balance Add another Card")
        
      }
    );
    }
  }
  addMoneyThroughUpi():void{
    if (!this.uamount) {
      alert("enter valid amount")
    }
    else{
    this.userService.addMoneyByUpi(this.mobileno,this.upiid,this.uamount,this.pin).subscribe((res: any) => {
     console.log("Added money");
      alert("Money Added")
    },
      (err) => {
        alert("Insufficient Balance Add another Card")
        
      }
    );
    }
  }

}
