import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddmoneytowalletComponent } from './addmoneytowallet.component';
import { AddcardtowalletComponent } from '../addcardtowallet/addcardtowallet.component';



@NgModule({
  declarations: [AddmoneytowalletComponent,AddcardtowalletComponent],
  imports: [
    CommonModule
  ]
})
export class AddmoneytowalletModule { }
