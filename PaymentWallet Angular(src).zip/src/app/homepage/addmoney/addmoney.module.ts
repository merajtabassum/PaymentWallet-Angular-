import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddmoneyComponent } from './addmoney.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { AddcardtowalletComponent } from './addcardtowallet/addcardtowallet.component';
import { AddmoneytowalletComponent } from './addmoneytowallet/addmoneytowallet.component';
import { AddmoneyService } from './addmoneyservice';
import { SetupiComponent } from './setupi/setupi.component';

@NgModule({
  declarations: [AddmoneyComponent,AddcardtowalletComponent,AddmoneytowalletComponent, SetupiComponent],
  imports: [ HttpClientModule,FormsModule ,RouterModule,AppRoutingModule,
    CommonModule
  ],
  providers: [AddmoneyService],
  bootstrap:[AddmoneyComponent],
 exports: [AddcardtowalletComponent,AddmoneytowalletComponent]
})
export class AddmoneyModule { }
