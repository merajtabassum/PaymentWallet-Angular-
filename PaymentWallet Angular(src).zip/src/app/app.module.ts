import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserModule } from './user/user.module';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { HomepageComponent } from './homepage/homepage.component';
import { AddmoneyComponent } from './homepage/addmoney/addmoney.component';
import { ShowtransactionsComponent } from './homepage/showtransactions/showtransactions.component';
import { TransferamounttoanotherwalletComponent } from './homepage/transferamounttoanotherwallet/transferamounttoanotherwallet.component';
import { ShowsenttransactionsComponent } from './homepage/showtransactions/showsenttransactions/showsenttransactions.component';
import { ShowrecievedtransactionsComponent } from './homepage/showtransactions/showrecievedtransactions/showrecievedtransactions.component';
import { ShowtransactionsbetweendatesComponent } from './homepage/showtransactions/showtransactionsbetweendates/showtransactionsbetweendates.component';
import { ShowwalletbalanceComponent } from './homepage/showwalletbalance/showwalletbalance.component';
import { AddcardtowalletComponent } from './homepage/addmoney/addcardtowallet/addcardtowallet.component';
import { AddmoneytowalletComponent } from './homepage/addmoney/addmoneytowallet/addmoneytowallet.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { SetupiComponent } from './homepage/addmoney/setupi/setupi.component';


@NgModule({
  declarations: [
    AppComponent,UserComponent,HomepageComponent,AddmoneyComponent,ShowtransactionsComponent,TransferamounttoanotherwalletComponent,ShowsenttransactionsComponent,ShowrecievedtransactionsComponent,ShowtransactionsbetweendatesComponent
   ,ShowwalletbalanceComponent,AddcardtowalletComponent,AddmoneytowalletComponent, SetupiComponent,PagenotfoundComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    UserModule,
    CommonModule,
    FormsModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
