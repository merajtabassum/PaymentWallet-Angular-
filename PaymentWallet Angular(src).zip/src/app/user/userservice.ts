import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Transaction } from '../homepage/showtransactions/transaction';


@Injectable({
    providedIn:'root'
})
export class UserService
{
    public constructor (private httpClient:HttpClient)
    {}
    sharedno:number;
    username:string;
    public createUser(body) : any
    {
        console.log(body)
        return this.httpClient.post<any>('http://localhost:2424/signup',body, {responseType:'text' as 'json'}) 
    }
    public loginUser(mobileno,password) 
    {
        
        console.log(" Login Hello")
        return this.httpClient.get<any>('http://localhost:2424/login/' + mobileno + '/' + password, {responseType:'text' as 'json'});
    }
    public transferAmount(mobileno,tomobileno,amount) 
    {
        console.log("Transferred Amount  Hello")
        return this.httpClient.get<any>('http://localhost:2428/transferAmount/' + mobileno + '/' + tomobileno+'/'+amount, {responseType:'text' as 'json'});
    }
    public sentTransactions(mobileno):Observable<Transaction[]>
    {
        console.log("Sent Transactions Hello")
        return this.httpClient.get<Transaction[]>(`http://localhost:2429/showSentTransactions/${mobileno}`);
    }
    public recievedTransactions(mobileno):Observable<Transaction[]>
    {
        console.log("Recieved Transactions Hello")
        return this.httpClient.get<Transaction[]>('http://localhost:2429/showRecievedTransactions/' + mobileno);
    }
    public transactionsByDates(fromdate,todate,mobileno):Observable<Transaction[]>
    {
        console.log("Show All Transactions Hello")
        return this.httpClient.get<Transaction[]>('http://localhost:2429/showAllTransactions/'+fromdate+'/'+todate+'/' + mobileno);
    }
    public showBalance(mobileno) :any
    {
        console.log("Wallet BalanceHello")
        return this.httpClient.get<number>('http://localhost:2427/walletBalance/' + mobileno, {responseType:'text' as 'json'});
    }
    public showAccBalance(mobileno) :any
    {
        console.log("Wallet BalanceHello")
        return this.httpClient.get<number>(`http://localhost:2426/showAccBalance/${mobileno}`, {responseType:'text' as 'json'});
    }
    public addCard(body,mobileno) : any
    {
        console.log(body)
        return this.httpClient.post<any>('http://localhost:2426/addcard/'+ mobileno,body, {responseType:'text' as 'json'}) 
    }
    public showCard(mobileno) :any
    {
        console.log("Card Hello")
        return this.httpClient.get<number>('http://localhost:2426/showAllCards/' + mobileno, {responseType:'text' as 'json'});
    }
    public showUpi(mobileno) :any
    {
        console.log("Card Hello")
        return this.httpClient.get<number>('http://localhost:2426/getUpi/' + mobileno, {responseType:'text' as 'json'});
    }
    public addMoneyToWallet(mobileno,cdno,amount,cvv) 
    {
        console.log("Transferred Amount  Hello")
        return this.httpClient.get<string>('http://localhost:2425/addMoney/' + mobileno + '/' + cdno+'/'+cvv+'/'+amount, {responseType:'text' as 'json'});
    }
    public setUpi(mobileno,pin)
    {
        return this.httpClient.get<any>('http://localhost:2425/setUpi/' + mobileno + '/' + pin, {responseType:'text' as 'json'});
    }
    public getUpiId(mobileno) :any
    {
        console.log("Card Hello")
        return this.httpClient.get<any>('http://localhost:8094/getUpiId/' + mobileno, {responseType:'text' as 'json'});
    }
    public addMoneyByUpi(mobileno,upiid,amount,pin) 
    {
        console.log("Transferred Amount  Hello")
        return this.httpClient.get<any>('http://localhost:2425/addMoneyByUpi/' + mobileno + '/' + upiid+'/'+pin+'/'+amount, {responseType:'text' as 'json'});
    }
    public transferAmountByUpi(mobileno,toupi,amount,pin)
    {
        return this.httpClient.get<string>('http://localhost:2428/upiTransfer/'+ mobileno+'/'+toupi+'/'+pin+'/'+amount, {responseType:'text' as 'json'});
    }
    public showUserProfile(mobileno)
    {
        return this.httpClient.get<any>('http://localhost:2424/profile/'+ mobileno)
    }
 }