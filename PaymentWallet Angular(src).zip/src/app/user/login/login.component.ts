import { Component, OnInit } from '@angular/core';
import { UserService } from '../userservice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public constructor(private userService:UserService, private router:Router){}

get mobileno():number{
  return this.userService.sharedno;
}
set mobileno(value:number)
{
  this.userService.sharedno=value;
}

 password:any;
  ngOnInit(): void {
  }
  login() {
    if (this.mobileno && this.password) {
      this.validate();
    } else {
      alert("Either of Mobile Number OR  Password is NULL");
    }
  }

  validate() {
    this.userService.loginUser(this.mobileno, this.password).subscribe((res: any) => {
      console.log('The user obj is ', res);
      this.router.navigate(['/homepage']);
    },
      (error) => {
        alert("invalid login credentials")
        
      }
    );
  }
 
}
