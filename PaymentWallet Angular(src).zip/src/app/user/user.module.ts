import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserComponent } from '../user/user.component';
import { SignupComponent } from './signup/signup.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; 
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from '../app-routing.module';
import { UserService } from './userservice';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [ SignupComponent,LoginComponent],
  imports: [ HttpClientModule,  CommonModule,FormsModule ,RouterModule,AppRoutingModule
  ],
  providers: [UserService],
  bootstrap:[UserComponent],
 exports: [ LoginComponent, SignupComponent ]
})
export class UserModule { }
