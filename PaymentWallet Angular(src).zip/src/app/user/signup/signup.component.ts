import { Component, OnInit } from '@angular/core';
import { UserService } from '../userservice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  public constructor(private userService:UserService,private router:Router){}
  data: any = {};
  ngOnInit(): void {
  }
  submit() {
    if (!this.data.name) {
      alert("Name cannot be null")
    } else if (this.data.password!=this.data.confirm) {
      alert("Please confirm your password correctly")
    } else if (!this.data.mobileno) {
          alert("phone number cannot be null")     
    } else if (!this.data.email) {
          alert("email cannot be null")          
    } else {
      let options = {
        params: this.data
      }
      this.userService.createUser(options.params).subscribe ((res: any) => {
        //this.router.navigate(['login']);
      });
  
}
  }
}
  
