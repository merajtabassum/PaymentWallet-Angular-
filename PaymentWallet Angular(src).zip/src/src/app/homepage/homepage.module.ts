import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomepageComponent } from './homepage.component';
import { AddmoneyComponent } from './addmoney/addmoney.component';
import { ShowtransactionsComponent } from './showtransactions/showtransactions.component';
import { ShowwalletbalanceComponent } from './showwalletbalance/showwalletbalance.component';
import { TransferamounttoanotherwalletComponent } from './transferamounttoanotherwallet/transferamounttoanotherwallet.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from '../app-routing.module';
import { HomepageService } from './hompageservice';
import { ShowtransactionsbetweendatesComponent } from './showtransactions/showtransactionsbetweendates/showtransactionsbetweendates.component';
import { UserService } from '../user/userservice';
import { Transaction } from './showtransactions/transaction';



@NgModule({
  declarations: [HomepageComponent, AddmoneyComponent,ShowtransactionsComponent,ShowwalletbalanceComponent,TransferamounttoanotherwalletComponent,ShowtransactionsbetweendatesComponent],
  imports: [ HttpClientModule,  CommonModule,FormsModule ,RouterModule,AppRoutingModule,Transaction
  ],
  providers: [HomepageService],
  bootstrap:[UserService],
 exports: [AddmoneyComponent,ShowtransactionsComponent,ShowwalletbalanceComponent,TransferamounttoanotherwalletComponent ]
})
export class HomepageModule { }
