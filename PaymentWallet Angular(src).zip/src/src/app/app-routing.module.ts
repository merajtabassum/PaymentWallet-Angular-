import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './user/login/login.component';
import { SignupComponent } from './user/signup/signup.component';
import { AddmoneyComponent } from './homepage/addmoney/addmoney.component';
import { ShowtransactionsComponent } from './homepage/showtransactions/showtransactions.component';
import { ShowwalletbalanceComponent } from './homepage/showwalletbalance/showwalletbalance.component';
import { TransferamounttoanotherwalletComponent } from './homepage/transferamounttoanotherwallet/transferamounttoanotherwallet.component';
import { AddcardtowalletComponent } from './homepage/addmoney/addcardtowallet/addcardtowallet.component';
import { AddmoneytowalletComponent } from './homepage/addmoney/addmoneytowallet/addmoneytowallet.component';
import { ShowtransactionsbetweendatesComponent } from './homepage/showtransactions/showtransactionsbetweendates/showtransactionsbetweendates.component';
import { ShowsenttransactionsComponent } from './homepage/showtransactions/showsenttransactions/showsenttransactions.component';
import { ShowrecievedtransactionsComponent } from './homepage/showtransactions/showrecievedtransactions/showrecievedtransactions.component';
import { HomepageComponent } from './homepage/homepage.component';
import { UserComponent } from './user/user.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { SetupiComponent } from './homepage/addmoney/setupi/setupi.component';


const routes: Routes = [{path:'paymentwallet',component:UserComponent,children:[
  {path:'login',component:LoginComponent},
{path:'signup',component:SignupComponent},],},



{path:'homepage',component:HomepageComponent,children:[
{path:'walletbalance',component:ShowwalletbalanceComponent},
{path:'transferamount',component:TransferamounttoanotherwalletComponent},
{path:'addmoney',component:AddmoneyComponent,children:[
  {path:'addcard',component:AddcardtowalletComponent},
  {path:'addmoneytowallet',component:AddmoneytowalletComponent},
  {path:'setupi',component:SetupiComponent}
]},
  {path:'transactions',component:ShowtransactionsComponent,children:[
  {path:'showbydate',component:ShowtransactionsbetweendatesComponent},
  {path:'showsent',component:ShowsenttransactionsComponent},
  {path:'showrecieved',component:ShowrecievedtransactionsComponent},],},],},

  { path: '',   redirectTo: '/paymentwallet', pathMatch: 'full' }, // redirect to `first-component`
  { path: '**', component:PagenotfoundComponent },  // Wildcard route for a 404 page

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }